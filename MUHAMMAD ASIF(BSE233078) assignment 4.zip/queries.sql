-- 1. Select all books priced above 5000
SELECT * FROM book WHERE Price > 5000;

-- 2. Select all orders made by 'muhammad khan'
SELECT * FROM `order` WHERE full_name = 'muhammad khan';

-- 3. Select all users with 'gmail.com' in their email
SELECT * FROM users WHERE email LIKE '%gmail.com';

-- 4. Select all books in the 'Cooking' genre
SELECT * FROM book WHERE Genre = 'Cooking';

-- 5. Select orders from the city 'Islamabad'
SELECT * FROM `order` WHERE address LIKE '%Islamabad%';

-- 6. Display only book titles and their authors
SELECT Title, Author FROM book;

-- 7. Display user names and their emails
SELECT name, email FROM users;

-- 8. Display order dates and quantities from 'order_items'
SELECT order_id, quantity FROM order_items;

-- 9. Join books with order items to display book titles and quantities ordered
SELECT book.Title, order_items.quantity 
FROM book 
JOIN order_items ON book.Title = order_items.book_name;

-- 10. Join users with orders to display user names and their order IDs
SELECT users.name, `order`.order_id 
FROM users 
JOIN `order` ON users.email = `order`.email;

-- 11. Join orders and order items to get total price per order
SELECT `order`.order_id, SUM(order_items.total_price) AS total_order_price
FROM `order`
JOIN order_items ON `order`.order_id = order_items.order_id
GROUP BY `order`.order_id;

-- 12. Count the number of books in the 'Fantasy' genre
SELECT COUNT(*) AS fantasy_books FROM book WHERE Genre = 'Fantasy';

-- 13. Find the total quantity of books ordered
SELECT SUM(quantity) AS total_books_ordered FROM order_items;

-- 14. Find the average price of books
SELECT AVG(Price) AS average_book_price FROM book;

-- 15. Get the maximum stock quantity of any book
SELECT MAX(Stock_Quantity) AS max_stock FROM book;

-- 16. Find the total revenue from all orders
SELECT SUM(total_price) AS total_revenue FROM order_items;

-- 17. Find all books that are out of stock
SELECT * FROM book WHERE Stock_Quantity = 0;

-- 18. Find users who placed the most recent order
SELECT * FROM users 
WHERE email = (SELECT email FROM `order` ORDER BY order_date DESC LIMIT 1);

-- 19. Find the most expensive book
SELECT * FROM book WHERE Price = (SELECT MAX(Price) FROM book);

-- 20. Find books ordered more than 5 times
SELECT book_name, SUM(quantity) AS total_quantity 
FROM order_items 
GROUP BY book_name 
HAVING total_quantity > 5;

-- 21. Insert a new book into the 'book' table
INSERT INTO book (Book_ID, Title, Author, Genre, Price, Stock_Quantity, image_url)
VALUES (21, 'New Book', 'Author Name', 'Genre', 4999, 50, 'images/newbook.jpg');

-- 22. Update the stock quantity of '1984'
UPDATE book SET Stock_Quantity = 25 WHERE Title = '1984';

-- 23. Delete an order with ID '26'
DELETE FROM `order` WHERE order_id = 26;

-- 24. Create a new user in the 'users' table
INSERT INTO users (user_id, name, email, password)
VALUES (37, 'John Doe', 'johndoe@gmail.com', 'password123');

-- 25. Retrieve all books ordered by 'muhammad khan'
SELECT DISTINCT book_name 
FROM order_items 
WHERE order_id IN (
    SELECT order_id FROM `order` WHERE full_name = 'muhammad khan'
);
